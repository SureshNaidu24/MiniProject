// src/pages/Login.js
import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import "./AuthForm.css";

const Login = () => {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", password: "" });
  const [msg, setMsg] = useState("");

  const submit = (e) => {
    e.preventDefault();
    const { success, message } = login(form.username, form.password);
    if (success) {
      navigate("/");
    } else {
      setMsg(message);
    }
  };

  return (
    <div className="auth-form">
      <h2>Login</h2>
      {msg && <p className="error">{msg}</p>}
      <form onSubmit={submit}>
        <input
          name="username"
          placeholder="Username"
          value={form.username}
          onChange={e => setForm({ ...form, username: e.target.value })}
          required
        />
        <input
          name="password"
          placeholder="Password"
          type="password"
          value={form.password}
          onChange={e => setForm({ ...form, password: e.target.value })}
          required
        />
        <button type="submit">Login</button>
      </form>
      <p>
        No account? <a href="/register">Register</a>
      </p>
    </div>
  );
};
export default Login;

