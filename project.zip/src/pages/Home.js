import React, { useContext, useState } from 'react';
import { TaskContext } from '../context/TaskContext';
import TaskForm from '../components/TaskForm';
import TaskList from '../components/TaskList';

const Home = () => {
  const { loading } = useContext(TaskContext);
  return (
    <div>
      <h1>Task Manager</h1>
      <TaskForm />
      {loading ? <p>Loading...</p> : <TaskList />}
    </div>
  );
};
export default Home;
