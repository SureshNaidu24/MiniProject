// src/pages/Register.js
import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import "./AuthForm.css";

const Register = () => {
  const { register } = useContext(AuthContext);
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", password: "" });
  const [msg, setMsg] = useState("");

  const submit = (e) => {
    e.preventDefault();
    const { success, message } = register(form.username, form.password);
    if (success) {
      navigate("/");
    } else {
      setMsg(message);
    }
  };

  return (
    <div className="auth-form">
      <h2>Register</h2>
      {msg && <p className="error">{msg}</p>}
      <form onSubmit={submit}>
        <input
          name="username"
          placeholder="Username"
          value={form.username}
          onChange={e => setForm({ ...form, username: e.target.value })}
          required
        />
        <input
          name="password"
          placeholder="Password"
          type="password"
          value={form.password}
          onChange={e => setForm({ ...form, password: e.target.value })}
          required
        />
        <button type="submit">Register</button>
      </form>
      <p>
        Already have an account? <a href="/login">Login</a>
      </p>
    </div>
  );
};
export default Register;
