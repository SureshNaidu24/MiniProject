import React from 'react';

const About = () => (
  <div>
    <h2>About</h2>
    <p>This is a simple Task Manager app built in React.</p>
  </div>
);
export default About;
