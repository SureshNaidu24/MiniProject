import React, { useContext, useState } from 'react';
import { TaskContext } from '../context/TaskContext';
import TaskItem from './TaskItem';

const TaskList = () => {
  const { tasks, setTasks } = useContext(TaskContext);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  const handleSearch = e => {
    setSearch(e.target.value);
    // Simple filter example
    setTasks(prev => prev.filter(task => task.title.toLowerCase().includes(e.target.value.toLowerCase())));
  };

  const handleFilterStatus = e => setFilterStatus(e.target.value);

  const filteredTasks = tasks.filter(task =>
    (filterStatus ? task.status === filterStatus : true)
  );

  return (
    <div>
      <input placeholder="Search..." value={search} onChange={handleSearch} />
      <select value={filterStatus} onChange={handleFilterStatus}>
        <option value="">All Statuses</option>
        <option value="To-do">To-do</option>
        <option value="In-progress">In-progress</option>
        <option value="Done">Done</option>
      </select>
      <ul>
        {filteredTasks.map(task => <TaskItem key={task.id} task={task} />)}
      </ul>
    </div>
  );
};
export default TaskList;
