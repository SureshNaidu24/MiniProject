import React, { useState, useContext } from 'react';
import { TaskContext } from '../context/TaskContext';

const TaskForm = () => {
  const { addTask } = useContext(TaskContext);
  const [task, setTask] = useState({
    title: '',
    category: 'Work',
    priority: 'Medium',
    status: 'To-do',
    dueDate: ''
  });

  const handleChange = e => setTask({ ...task, [e.target.name]: e.target.value });

  const handleSubmit = e => {
    e.preventDefault();
    if (!task.title.trim()) return;
    addTask(task);
    setTask({ title: '', category: 'Work', priority: 'Medium', status: 'To-do', dueDate: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="title" value={task.title} onChange={handleChange} placeholder="Task Title" required />
      <select name="category" value={task.category} onChange={handleChange}>
        <option value="Work">Work</option>
        <option value="Personal">Personal</option>
      </select>
      <select name="priority" value={task.priority} onChange={handleChange}>
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
      </select>
      <select name="status" value={task.status} onChange={handleChange}>
        <option value="To-do">To-do</option>
        <option value="In-progress">In-progress</option>
        <option value="Done">Done</option>
      </select>
      <input type="date" name="dueDate" value={task.dueDate} onChange={handleChange} />
      <button type="submit">Add Task</button>
    </form>
  );
};
export default TaskForm;
