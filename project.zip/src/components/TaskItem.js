import React, { useContext, useState } from 'react';
import { TaskContext } from '../context/TaskContext';

const TaskItem = ({ task }) => {
  const { deleteTask, updateTask } = useContext(TaskContext);
  const [editing, setEditing] = useState(false);
  const [editTask, setEditTask] = useState({ ...task });

  const handleEditChange = e => setEditTask({ ...editTask, [e.target.name]: e.target.value });

  const submitEdit = e => {
    e.preventDefault();
    updateTask(task.id, editTask);
    setEditing(false);
  };

  return (
    <li>
      {editing ? (
        <form onSubmit={submitEdit}>
          <input name="title" value={editTask.title} onChange={handleEditChange} />
          <button type="submit">Save</button>
        </form>
      ) : (
        <>
          <span>{task.title} | {task.category} | {task.priority} | {task.status} | {task.dueDate}</span>
          <button onClick={() => setEditing(true)}>Edit</button>
          <button onClick={() => deleteTask(task.id)}>Delete</button>
        </>
      )}
    </li>
  );
};
export default TaskItem;
