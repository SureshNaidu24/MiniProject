import React, { createContext, useState, useEffect } from "react";

const USERS_KEY = "task_manager_users";
const AUTH_KEY = "task_manager_auth";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  // On mount, get logged-in user
  useEffect(() => {
    const logged = localStorage.getItem(AUTH_KEY);
    if (logged) setUser(JSON.parse(logged));
  }, []);

  // Helpers for registration and login
  const register = (username, password) => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
    if (users.find((u) => u.username === username)) {
      return { success: false, message: "Username already exists" };
    }
    users.push({ username, password });
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    localStorage.setItem(AUTH_KEY, JSON.stringify({ username }));
    setUser({ username });
    return { success: true };
  };

  const login = (username, password) => {
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
    const found = users.find((u) => u.username === username && u.password === password);
    if (found) {
      localStorage.setItem(AUTH_KEY, JSON.stringify({ username }));
      setUser({ username });
      return { success: true };
    } else {
      return { success: false, message: "Invalid credentials" };
    }
  };

  const logout = () => {
    localStorage.removeItem(AUTH_KEY);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, register, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
