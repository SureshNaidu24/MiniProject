import React, { createContext, useState, useEffect } from 'react';

export const TaskContext = createContext();

const TASKS_STORAGE_KEY = 'task_manager_tasks';

export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedTasks = localStorage.getItem(TASKS_STORAGE_KEY);
    if (storedTasks) {
      setTasks(JSON.parse(storedTasks));
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!loading) {
      localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
    }
  }, [tasks, loading]);

  const addTask = (task) => {
    const newTask = { ...task, id: Date.now() }; 
    setTasks(prev => [...prev, newTask]);
  };

  const updateTask = (id, updatedTask) => {
    setTasks(prev =>
      prev.map(task => (task.id === id ? { ...task, ...updatedTask } : task))
    );
  };

  const deleteTask = (id) => {
    setTasks(prev => prev.filter(task => task.id !== id));
  };

  return (
    <TaskContext.Provider value={{
      tasks, loading, addTask, updateTask, deleteTask, setTasks
    }}>
      {children}
    </TaskContext.Provider>
  );
};
